/* eslint-disable no-undef */
/* eslint-disable no-unused-vars */

/**
 * Search function
 */

const searchInput = document.querySelector("#searchbar > input")
const searchButton = document.querySelector("#searchbar > button")

const lookup = {"/":"/","reddit":"https://reddit.com/","maps":"https://maps.google.com/","desmos":"https://www.desmos.com/calculator","calculator":"https://www.desmos.com/scientific","email":"https://mail.google.com/mail/u/0/","prayer times":"https://timesprayer.com/en/prayer-times-in-amman.html","小説":"https://yonde.itazuraneko.org","manga":"https://mangareader.to","opengl wiki":"https://www.khronos.org/opengl/wiki/Main_Page"}
const engine = "https://lite.duckduckgo.com/lite/?q={query}"
const engineUrls = {
  deepl: "https://www.deepl.com/translator#-/-/{query}",
  duckduckgo: "https://duckduckgo.com/?q={query}",
  ecosia: "https://www.ecosia.org/search?q={query}",
  google: "https://www.google.com/search?q={query}",
  startpage: "https://www.startpage.com/search?q={query}",
  youtube: "https://www.youtube.com/results?q={query}",
}

const isWebUrl = value => {
  try {
    const url = new URL(value)
    return url.protocol === "http:" || url.protocol === "https:"
  } catch {
    return false
  }
}

const getTargetUrl = value => {
  if (isWebUrl(value)) return value
  if (lookup[value]) return lookup[value]
  const url = engineUrls[engine] ?? engine
  return url.replace("{query}", value)
}

const search = () => {
  const value = searchInput.value
  const targetUrl = getTargetUrl(value)
  window.open(targetUrl, "_self")
}

searchInput.onkeyup = event => event.key === "Enter" && search()
searchButton.onclick = search

/**
 * inject bookmarks into html
 */

const bookmarks = [{"id":"VYwfUNoEWhwyQV6h","label":"/media","bookmarks":[{"id":"H9tRtawVQ9KqhZk7","label":"anime","url":"https://www.nyaa.si"},{"id":"boXbjVvt6iqjQ9av","label":"movies","url":"https://fmoviesz.to/"},{"id":"b0OVvuBMzN1mhCo5","label":"books","url":"https://yonde.itazuraneko.org"},{"id":"FJgYDLVlLLT23bCM","label":"drama","url":"https://drama-otaku.com/"}]},{"id":"uPGNResOrOIKXum3","label":"/personal","bookmarks":[{"id":"pdFAjPoRLXz4A2UZ","label":"youtube","url":"https://www.youtube.com"},{"id":"2poKhn6L6Hs08nMS","label":"github","url":"https://www.github.com"},{"id":"Zh4UCNm5y5HaLHZ1","label":"mal","url":"https://myanimelist.net/profile/Nix3l"},{"id":"zyITQgind49kWIVI","label":"learn natively","url":"https://learnnatively.com/dashboard/"}]},{"id":"MslFTfo0tsI1hXit","label":"/hobbies","bookmarks":[{"id":"0hFkGYzso7Dd0501","label":"jisho","url":"https://www.jisho.org"},{"id":"exBLCRMuFxIC7yVo","label":"weblio","url":"https://www.weblio.jp"},{"id":"WpwOeCoWyzdY2WVr","label":"imabi","url":"https://imabi.org/table-of-contents-%e7%9b%ae%e6%ac%a1/"}]}]

const createGroupContainer = () => {
  const container = document.createElement("div")
  container.className = "bookmark-group"
  return container
}

const createGroupTitle = title => {
  const h2 = document.createElement("h2")
  h2.innerHTML = title
  return h2
}

const createBookmark = ({ label, url }) => {
  const li = document.createElement("li")
  const a = document.createElement("a")
  a.href = url
  a.innerHTML = label
  li.append(a)
  return li
}

const createBookmarkList = bookmarks => {
  const ul = document.createElement("ul")
  bookmarks.map(createBookmark).forEach(li => ul.append(li))
  return ul
}

const createGroup = ({ label, bookmarks }) => {
  const container = createGroupContainer()
  const title = createGroupTitle(label)
  const bookmarkList = createBookmarkList(bookmarks)
  container.append(title)
  container.append(bookmarkList)
  return container
}

const injectBookmarks = () => {
  const bookmarksContainer = document.getElementById("bookmarks")
  bookmarksContainer.append()
  bookmarks.map(createGroup).forEach(group => bookmarksContainer.append(group))
}

injectBookmarks()
